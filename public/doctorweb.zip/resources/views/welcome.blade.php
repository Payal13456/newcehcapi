@extends('layouts.adminlayout.admin')

@section('content')
    <h1>Pankaj</h1>
@endsection