require('./bootstrap');
Vue.component("agora-chat", require("./components/AgoraChat.vue").default);
