<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
  <div class="row">
    <div class="col-12 d-flex no-block align-items-center">
      <h4 class="page-title">Edit Hospital Details</h4>
      <div class="ms-auto text-end">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">
              Hospital
            </li>
          </ol>
        </nav>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid">
  <div class="card">
    <div class="card-body wizard-content">
      <form id="editHospitalForm" method="post" action="<?php echo e(route('hospital.update',$getHospital->id)); ?>" name="editHospitalForm" autocomplete="off" enctype="multipart/form-data">
         <?php echo method_field('PUT'); ?>
        <div class="row">
          <div class="col-lg-6  mt-3">
            <label for="name">Hospital Name *</label>
            <input id="name" value="<?php echo e(ucfirst($getHospital->name)); ?>" name="name" type="text"
            class="required form-control">
            <span class="text-danger error-text name_err">
          </div>
          <div class="col-lg-6  mt-3">
            <label for="email">Email *</label>
            <input id="email" value="<?php echo e($getHospital->email); ?>" name="email" type="text"
            class="required form-control"/>
            <span class="text-danger error-text email_err">
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6  mt-3">
            <label for="primary_number">Primary Phone *
              <small class="text-muted">(999) 999-9999</small>
            </label>
            <input id="primary_number"  value="<?php echo e($getHospital->primary_number); ?>"  name="primary_number" type="text" class="required primary_number phone-inputmask form-control"/>
            <span class="text-danger error-text primary_number_err">
          </div>
          <div class="col-lg-6  mt-3">
            <label for="secondary_number">Secondary Phone *
              <small class="text-muted">(999) 999-9999</small>
            </label>
            <input id="secondary_number"  value="<?php echo e($getHospital->secondary_number); ?>"  name="secondary_number"type="text" class="required phone-inputmask secondary_number form-control"/>
             <span class="text-danger error-text secondary_number_err">
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6  mt-3">
            <label for="description">Select Employee For Manage Hospital *</label>
               <select id="user_id" name="user_id" required="" class="select2 form-select shadow-none form-control" style="width: 100%; height: 36px">
                     <option value="">Select</option>
                     <?php if(!empty($getEmployees)): ?>
                     <?php $__currentLoopData = $getEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->id); ?>" <?php echo e(( $employee->id == $getHospital->user_id) ? 'selected' : ''); ?>><?php echo e(ucfirst($employee->first_name)); ?>  <?php echo e(ucfirst($employee->last_name)); ?> | <?php echo ucfirst($employee->user->email);  ?> | <?php echo ucfirst($employee->roles->name);  ?> </option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
              </select>
              <span class="text-danger error-text user_id_err"></span>
          </div>
          <div class="col-lg-6  mt-3">
            <label for="location">Map Location Link </label>
            <input id="location"   value="<?php echo e($getHospital->location); ?>" name="location" type="text"
            class="required location form-control"/>
            <span class="text-danger error-text location_err"></span>
          </div>
        </div>
        <div class="row">
            <div class="col-lg-6 mt-3 ">
              <label for="city">City *</label>
              <input id="city" value="<?php echo e($getHospital->city); ?>" name="city" type="text"
                class="form-control" value="" required/>
                <span class="text-danger error-text city_err">
                </span>  
            </div>
            <div class="col-lg-6 mt-3">
              <label for="state_id">State *</label>
              <select name="state_id" id="state_id" class=" form-control" required>
               <option value="">Select</option>
                <?php if(!empty($getAllState)): ?>
                <?php $__currentLoopData = $getAllState; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($state->id); ?>" <?php echo ($getHospital->state_id==$state->id)?"selected":""; ?>><?php echo e($state->state_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
             </select>
              <span class="text-danger error-text state_id_err">
             </span>
            </div>
          </div> 
      <div class="row">
        <div class="col-lg-6  mt-3">
          <label for="address">Address *</label>
          <textarea class="form-control" rows="7" cols="5"
          id="address" name="address" type="text"/>
           <?php echo e($getHospital->address); ?>  
          </textarea>
          <span class="text-danger error-text address_err"></span>
        </div>
        <div class="col-lg-6  mt-3"></div>
      </div>
      <div class="row">
        <div class="col-lg-6  mt-3">
          <button type="submit" class="btn btn-info" data-submit="submit">Submit</button>
        </div>
        <div class="col-lg-6  mt-3"></div>
      </div>
      <!-- </section> -->
    <section></section>
    <!-- </div> -->
  </form>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cis/doctor-online-video-consultation-web/resources/views/admin/hospitals/edit.blade.php ENDPATH**/ ?>