<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/index.css')); ?>">
    <?php $user = Session::get('user'); ?>  
	<h4 style="text-align: center;color: blue;">Appointment with <?php echo e($user->name); ?></h4>
    <input type="hidden" id="token" name="token" value="<?php echo e($data->token); ?>">
    <input type="hidden" id="channel_name" name="channel_name" value="<?php echo e($data->channel_name); ?>">
    <input type="hidden" name="uid" id="uid" value="<?php echo e($user->name); ?>">
    <section id="video-container" v-if="callPlaced">
        <div id="me"></div>
        <div id="remote-container"></div>
        <div class="action-btns">
            <button type="button" class="btn btn-info" onclick="handleAudioToggle()">Mute/Unmute
            </button>
            
            <button
              type="button"
              class="btn btn-primary mx-4"
              onclick="handleVideoToggle()"
            >ShowVideo/HideVideo
            </button>

            <button type="button" class="btn btn-danger" onclick="endCall()">
              EndCall
            </button>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript" src="<?php echo e(url('assets/js/agora.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cis/payal-project/doctor-web/resources/views/admin/agora-chat.blade.php ENDPATH**/ ?>