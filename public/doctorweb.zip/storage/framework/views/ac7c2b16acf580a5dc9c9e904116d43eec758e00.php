<?php $__env->startSection('content'); ?>
<div class="page-breadcrumb">
  <div class="row">
    <div class="col-12 d-flex no-block align-items-center">
      <h4 class="page-title">Upcomming Appointment</h4>
      <div class="ms-auto text-end">
        <?php $user = Session::get('user'); ?>  
        <?php if($user->role_id != 1): ?>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('appointment.create')); ?>" class="btn btn-info">Add New Appointment</a></li>
          </ol>
        </nav>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <!-- <div class="todo-widget scrollable" style="height: 450px"> -->
          <div class="table-responsive">
            <table id="zero_config" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Sr.no</th>
                  <th>Patient Name</th>
                  <th>Doctor Name</th>
                  <th>Specification</th>
                  <th>Appointment date</th>
                  <th>Time</th>
                  <th>Type</th>
                  <th>Patient Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $user = Session::get('user'); ?>  
                <?php  $i = 1; ?>
                <?php if(!empty($appointments)): ?>
                  <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($key+1); ?></td>
                      <td><?php if($a->patient != NULL): ?><?php echo e($a->patient->first_name); ?> <?php echo e($a->patient->last_name); ?> <?php else: ?> NA <?php endif; ?></td>
                      <td><?php if($a->doctor != NULL): ?><?php echo e($a->doctor->first_name); ?> <?php echo e($a->doctor->last_name); ?> <?php else: ?> NA <?php endif; ?></td>
                      <td><?php echo e($a->specialization->specialization); ?></td>
                      <td><?php echo e(date("d M Y", strtotime($a->schedule_date))); ?></td>
                      <td><?php echo e(date("h:i A",strtotime($a->slot_timing))); ?></td>
                      <td><?php echo e($a->type); ?></td>
                      <td><?php echo e(($a->patient->type_of_patient == 1) ? 'Free Patient' : 'Paid Patient'); ?></td>
                      <td>
                        <?php if($a->status != 1): ?><a href="<?php echo e(route('appointment.more', $a->id)); ?>" class="fas fa-prescription fa-2x text-info" title="Prescription"></a> &nbsp;
                          <?php if($a->payment_id  != NULL || $a->patient->type_of_patient == 1): ?>
                            <a href="<?php echo e(route('appointment.edit', $a->id)); ?>" class="fas fa-calendar-alt fa-2x text-success" title="Reschedule"></a> &nbsp;
                            <?php $statusColor = ($a->status == 1) ? 'text-success' : 'text-danger';
                             ?>
                            <span><a href="javascript:void(0)" class="change_userStatus cursor fa fa-ban fa-2x delete_random <?php echo e($statusColor); ?>" data-type="status" data-toggle="tooltip" data-status="<?php echo e((($a->status == 1) ? '0' : '1')); ?>" data_userId='<?php echo e($a->id); ?>' data-placement="top" title="Cancel Booking"></a>&nbsp;</span>
                          <?php endif; ?>
                          <?php if($user->role_id == 1 && date('Y-m-d') <= date('Y-m-d',strtotime($a->schedule_date))): ?>
                            <a href="javascript:void(0);" class="fa fa-video fa-2x" title="Video Call" onClick=window.open("<?php echo e(url('appointment-call')); ?>/<?php echo e($a->id); ?>","Ratting","width=1000,height=1000,left=0,top=0,toolbar=0,status=0,");></a>
                          <?php endif; ?>
                        <?php else: ?>
                          <a href="javascript:void(0);" class="text text-danger">Cancelled</a>
                        <?php endif; ?>
                       <?php if($user->role_id != 1 && $a->patient->type_of_patient != 1): ?><a href="<?php echo e(route('payment.page', $a->id)); ?>" class="fa  fa-credit-card fa-2x" title="Payment"></a> &nbsp; <?php endif; ?>
                    </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
          <!-- </div> -->
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" role="dialog" style="" id="modal_remove_element_blog_status">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="title">Confirm Message</h5>
        <button type="button" class="close" data-dismiss="modal" onclick="$('#modal_remove_element_blog_status').modal('hide');">&times;</button>
      </div>
      <div class="modal-body" id="detail" style="">
        <div class="row">
          <div class="col s12 m12">
            <div class="form-group col s12">
              <div id="remove_element_message_status" style="">Do you really want to Cancel Booking!!</div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary btn-fw" style="" id="remove_element_status" ><?php echo('Yes'); ?></button>
        <button class="btn btn-primary btn-fw" data-dismiss="modal" onclick="$('#modal_remove_element_blog_status').modal('hide');"><?php echo('NO'); ?></button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript">
    $(document).on('click', '.change_userStatus', function (e) {
         userId= $(this).attr("data_userId");
         status =$(this).attr("data-status");
         type = $(this).attr("data-type");
          $("#remove_element_status").attr("data-type",type);
         $("#remove_element_status").attr("data_userId",userId);
         $("#remove_element_status").attr("data-status",status);
         $("#modal_remove_element_blog_status").modal("show");

     });
   $(document).on('click', '#remove_element_status', function (e) {
         userId= $(this).attr("data_userId");
         status =$(this).attr("data-status");
         type  = $(this).attr('data-type');
        param = {};
        param.userId = userId;
        param.status = status;
        param.type = type;
        $("#modal_remove_element_user_status").modal("hide");
        sendRequest($(this), base_url+"/cancelBooking" ,'post', param);
     });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/payal/payal/ArunProject/doctor-web/resources/views/admin/appointments/list.blade.php ENDPATH**/ ?>